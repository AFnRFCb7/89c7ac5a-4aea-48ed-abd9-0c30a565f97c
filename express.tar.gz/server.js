const express = require("express") ;
const app = express() ;
const port = 3000 ;
app.get("/hello", (request, response) =>
    {
        const name = request.query.name || "world" ;
        response.send( `hi ${ name }`) ;
    } ) ;
app.listen( port, () => { console.log(`listening on port ${ port }`) ; } ) ;
